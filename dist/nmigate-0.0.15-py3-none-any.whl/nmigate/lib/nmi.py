


class Nmi:
    def __init__(self, token, org):
        self.security_token = token
        self.org = org

